# Patient Apes — updated upload pack (REFORMED version, 2026-11-25)

This pack replaces the earlier gallery-version pack. Do NOT use the old zip.

## What's in here

- `index.html` — the reformed Patient Apes home page (text-first, whimsical-but-uncanny,
  opening with your Repo 1 text verbatim). All 6 images are embedded inside this one file,
  so there is no assets folder to upload.
- `rorschach/index.html` — the Rorschach Dark Triad Mode examination, as a sub-section.
  The home page's Examination Room links to `rorschach/`, so this folder makes that work.
- `README.md` — this file (you don't need to upload it, but it does no harm).

## Upload steps (GitHub website, no command line)

Target repo: **patientapes/patientapes.github.io** (the one with the CNAME file — do not touch CNAME or Meridian.html)

1. Unzip this pack on your computer.
2. Go to https://github.com/patientapes/patientapes.github.io
3. Click **Add file → Upload files**.
4. Drag in `index.html` AND the whole `rorschach` folder.
   - Note: GitHub's web uploader can be fussy about folders in some browsers.
     If the folder won't drag, upload `index.html` first, commit, then open the repo,
     click **Add file → Create new file**, type `rorschach/index.html` as the name,
     and paste/upload the rorschach file's contents — or tell Atlas and we'll find another way.
5. Write a commit message like "Patient Apes home page, reformed" and click **Commit changes** (to `main`).
6. Wait 1–3 minutes. GitHub Pages publishes automatically.
7. Visit https://www.patientapes.org — the home page should appear.
   The examination lives at https://www.patientapes.org/rorschach/

## Later tidy-ups (not required to go live)

- Plain patientapes.org (no www) redirecting to www.patientapes.org — a Cloudflare step.
- patientapes.com pointing at the same site — also Cloudflare, after the .org site works.
